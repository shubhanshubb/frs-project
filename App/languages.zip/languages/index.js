import en from './en';

export { en };
